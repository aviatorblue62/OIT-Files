/* This is the EE333 Lab Starting Point. The spots marked with *** are the best places to add your
 * code. Values stored in the four bytes starting at disptn will be displayed on the 7-segment display.
 * The mapping between the values and the character displayed is done by table segm_ptrn. The values 0
 * through 9 display the characters "0" through "9" which is generally convenient.
 * The light sensor amplitude is the 16 bit value at ADR04H and will be in the range 0 to 1023.
 * The Trimmer pot position is in the 16 bit value at ADR07H and will be in the range 0 to 1023.
 * Example program written by Tom Almy, July, 2012
 */

#define INTERRUPT __attribute__((interrupt))
#include"vectors12.h"
#include"ioregs12.h"

typedef unsigned int  uint16_t;
typedef unsigned char uint8_t;
typedef int int16_t;

uint8_t chr; /* Character last displayed (index 0, 1, 2, 3, 4 for LEDs) */
uint8_t disptn[4] = {0x91, 0x0e, 0x14, 0x18}; /* These four bytes will be displayed */
uint8_t displ = 0x5a;	/* This will be displayed in the row of LEDs */
uint16_t setpoint = 80;	/* Thermostat setpoint */

// *** Add your variables here

// ***

const uint8_t dspmap[4] = {0x0e, 0x0d, 0x0b, 0x07}; // Selects the correct character for lighting

const uint8_t segm_ptrn[] = { // segment pattern
    0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,          // 0-7
    //                0,  1,  2,  3,  4,  5,  6,  7
    0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71,          // 8-15
    //                8,  9,  A,  b,  C,  d,  E,  F
    0x3d,0x76,0x74,0x1e,0x38,0x54,0x63,0x5c,          // 16-23
    //                G,  H,  h,  J   L   n   o   o
    0x73,0x50,0x78,0x3e,0x1c,0x6e,0x08,0x40,          // 24-31
    //                P,  r,  t,  U,  u   Y   _   -
    0x00                                      // 32
    //               blk
};

// *** Add any tables or other constant values here

// ***


void INTERRUPT rtiISR(void);

int main(void) {
    __asm__  __volatile__ (" sei ");    /* Disable interrupts */

    UserRTI = (unsigned int) &rtiISR;

    /* Configure ports B and P for output, turn off 7 segment display, set port J pin 1 for output */
    DDRB = 0xff;
    DDRP = 0xff;
    PTP = 0x0f;
    DDRJ |= 2;

    /* configure RTI divider to be 8192, 1.024 mSec */
    RTICTL = 0x17;
    CRGINT |= 0x80;

    /* Turn on and configure ATD for 8 conversions, mult and scan mode, right justify */
    ATD0CTL2 = 0x80;
    ATD0CTL3 = 0;
    ATD0CTL5 = 0xb0;

// *** Any code you need to initialize should go here

// ***
    __asm__  __volatile__ (" cli ");    /* Enable interrupts */

    for (;;)
    {  // Idle process
        __asm__ __volatile__ (" wai ");
// *** Code you need to execute repeatedly should go here

// ***
    }
    return 0;	// Actually never returns
}

void INTERRUPT rtiISR(void)
{
    CRGFLG &= 0x80;   // Clear RTI Flag
    if (++chr >= 5) chr = 0; // rotate through five values, 0 through 4
    __asm__  __volatile__ (" cli ");    /* Enable interrupts */

    if (chr < 4)
    {   // 7 segment digit needs to be lit
        uint8_t temp;   // Temporary variable for calculations
        PTJ |= 2; // Turn off LED row
        temp = disptn[chr];
        PORTB = segm_ptrn[temp&0x7f] | (temp&0x80); // Calculate and send digit byte
        PTP = (PTP & 0xf0) | dspmap[chr]; // Light the correct digit, leave upper bits of port unchaged
    }
    else
    { // LED row needs to be lit
        PTP |= 0x0f;    // turn off seve segment LEDs
        PORTB = displ;  // Set value of LED row
        PTJ &= ~2;      // Turn on LED row
    }
// *** Any code you place here will execute every 1.024 milliseconds

// ***
}
