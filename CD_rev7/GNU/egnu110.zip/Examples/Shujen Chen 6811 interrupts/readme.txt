This example from Shujen Chen is for a FOX11 board.

This uses an interrupt handler to flash an LED.

