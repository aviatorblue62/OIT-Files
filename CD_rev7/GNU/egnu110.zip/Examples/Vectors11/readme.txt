
This is a sample project to show how to use interrupts in a C program.
This demo is for the hc11e9 MPU.

There are 2 ways this could be done: 

 1) Define the interrupts in an assembler module (normally called vectors.s)

 2) Define the interrupts in a C module (normally called vectors.c)

This example uses #1. It doesn't matter which way you do it, since
the vector definitions are very small. Many people prefer to use the
assembly language method of declaring the interrupts because the
syntax seems cleaner.

You need to be careful about where your interrupt vectors are 
located. 

This example is for the hc11e9 MPU. This device does not have
a monitor program, so the interrupt vectors are in the standard
locations (0xFFC0 to 0xFFFF).

There's two places where you need to specify where the interrupt
vectors are located:

 1) your hardware profile (used to create the memory.x file).
    This is accessed through Options, Project Options, Edit Profile.

 2) your vectors.s file (or vectors.c if you want to use that)


There are 3 steps you need to do:

  1) define where the vector table is located. I added this to the 
     hardware profile. This goes into the linker script file (memory.x)

  2) you need to provide an assembler or C file that lists the interrupt
     vectors. This is where you assign a name to the interrupts you want
     to use and specify the address of each vector.

  3) write an interrupt handler function in C for each vector you want
     to intercept

If you're using an "EVB" type of MPU that has an internal monitor like
d-bug12 or Buffalo, then the procedures are slightly different. If you 
are operating in "EVB" mode, you need to set your vectors in RAM when
the program starts. 

Thanks to John Hilton for providing this sample program!

Eric Engler