#ifndef ISR_H
#define ISR_H

#include "HobbyKit.h"

#define DISABLE_INTERRUPTS asm("sei")  // disable interrupts
#define ENABLE_INTERRUPTS  asm("cli")  // enable interrupts
#define ISR void __attribute__((interrupt))

ISR TC6Handle(void);
void TC6init(unsigned int delay);
void RTIinit(BYTE scale);
ISR RTIHandle();

#endif
