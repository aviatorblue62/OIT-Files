
This program was donated by Steven Lamb. 

This is a OSCILLOSCOPE/Digial analzer program for the 9S12C32. 
This was tested on a NanoCore12 DIP module from Technological Arts:
http://www.technologicalarts.com/myfiles/nc12.html

This embedded project talks to a custom program on the PC. 
This is written in VB, and the source code for this project
is provided also. The compiled .exe for this PC project is 
included to assist those people who many not have Visual
Basic on their PC. 
