MiniDragon+ Demo Features:

   1. The LED will count. If you press any of the switches (1-4) it will count faster
   2. The pot will act as a brightness control for the LED and the scroll rate of the LCD.
   3. A song will play. If you put a jumper on sw4 it will only play once.
   4. If you have an LCD connected, the current ADC value will be displayed.
   5. If you have the keypad connected, pressed keys will be displayed on the LCD. 
      If it is a 20x4 LCD, the lower two lines will have text displayed.
