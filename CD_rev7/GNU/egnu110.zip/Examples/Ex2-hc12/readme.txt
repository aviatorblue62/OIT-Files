This is a simple program that flashes the LEDs on the
Wytec Dragon12 development board. This board uses a
MC9S12DP256 (a type of 68hc12) processor.

http://www.evbplus.com/