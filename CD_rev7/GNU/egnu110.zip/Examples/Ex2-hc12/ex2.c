#include  <stdio.h>
#include  <string.h>
#include  "ioregs12.h"

int  main(void);
void delay(void);

unsigned short int  speed = 0xffff;

unsigned short int        start = 0x0000;
unsigned short int        end   = 0xffff;

int main()
{
    unsigned short int n;

    COPCTL = 0x08; /* COP watchdog timer */
    COPCTL = 0x08;
   
    DDRB = 0xff; /* make all bits of port B outputs */
    
    /* DDRP = 0xff; -* make all bits of port P outputs */
    /* PTP = 0xff;  * turn-off 7 segment display */
    
    while (1)
    {
        for (n = start; n < end; n++)
        {
          PORTB = n;
          delay();
        }
    }
    return  0; /* not used */
}

void delay()
{
  unsigned short int i;

  for (i = 0; i < speed; i++)
  {
   /* nothing */
  } 
}


  
