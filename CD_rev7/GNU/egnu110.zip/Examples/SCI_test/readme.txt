This program was donated by Steven Lamb. 

This is a simple SCI I/O pprogram written for the 9S12C32.

This was tested on a NanoCore12 DIP module from Technological Arts:
http://www.technologicalarts.com/myfiles/nc12.html