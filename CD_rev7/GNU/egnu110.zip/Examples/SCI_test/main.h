//
// utilities
//
#define BIT0 0b00000001
#define BIT1 0b00000010
#define BIT2 0b00000100
#define BIT3 0b00001000
#define BIT4 0b00010000
#define BIT5 0b00100000
#define BIT6 0b01000000
#define BIT7 0b10000000

#define bit(x) (1 << (x))
#define SETBIT(port,b) (port|=bit(b))
#define CLRBIT(port,b) (port&=~bit(b))
#define FLIPBIT(port,b) (port^=bit(b))

