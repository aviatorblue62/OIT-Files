vect12-flasher and vect12-serial are 2 demo projects here from Tom Almy. 

These demos show you how to use vectored interrupts on the mc9s12DP256
in EVB mode using the d-bug12 monitor.
 
These demos were tested with a Dragon12 board from Wytec (www.evbplus.com).

"flasher" will flash the LED connected to the LSB of Port B at a rate
of once per second.

"serial" is a buffered serial port program.