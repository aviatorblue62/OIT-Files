#include  <stdio.h>
#include  <string.h>

int  main(void);
void delay(void);

unsigned short int  speed = 0xffff;

unsigned short int        start = 0x0000;
unsigned short int        end   = 0xffff;

#define  IOREGS_BASE    0x1000
#define _IO8(off)       *(unsigned char  volatile *)(IOREGS_BASE + off)
#define  PORTB      _IO8(0x04)      /* i/o port b */

int main()
{
    unsigned short int n;

    while (1)
    {
        for (n = start; n < end; n++)
        {
          PORTB = n;
          delay();
        }
    }
    return  0; /* not used */
}

void delay()
{
  unsigned short int i;

  for (i = 0; i < speed; i++)
  {
   /* nothing */
  } 
}


  
