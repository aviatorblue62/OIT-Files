This is a simple program that flashes the LEDs on the
Wytec EVBPlus2 development board. This board uses a
68hc11 processor.

http://www.evbplus.com/