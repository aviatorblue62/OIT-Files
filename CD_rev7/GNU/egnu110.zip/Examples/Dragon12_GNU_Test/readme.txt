Dragon 12 demo features:

   1. If you connect a scope to the DAC output, you will see a sine wave on channel A and a 
      ramp on channel B. SW 2-5 and or DIP SW 1-4 will multiply the frequency of the waves. 
      For DIP sw1-4, all up is fundamental, all down is off, 0001 is fundamental, 0010 is x2,
      0011 is x3 etc. There is an 8 bit sine table used.
   2. The LEDs will count. SW 2-5 and/or DIP SW 1-4 will control the count rate. The ADC 
      controls the brightness of just the 7 segments.
   3. The switches set the single row LEDs
   4. The pot will act as a brightness control for the LED and the scroll rate of the LCD.
   5. A song will play. If you lower DIP switch 8 it will only play once.
   6. The current ADC value will be displayed on the LCD.
   7. The 2nd line of the LCD will scroll. The pot controls the scroll rate.
   8. If you have the keypad connected, press keys will be displayed on the LCD
   9. If it is a 20x4 LCD the lower two lines will have text displayed.
