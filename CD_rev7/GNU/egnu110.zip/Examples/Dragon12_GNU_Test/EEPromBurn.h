//===============================================================================
// Routines to save in EE Prom
// Does NOT need DBUG-12
//===============================================================================


//===============================================================================
// YOU MUST CALL THIS FIRST!!!
//===============================================================================
void InitEEProm();


byte WriteEEWord(word* address, word data );
byte WriteEEByte(byte* address, byte data );
byte __ExecuteEECmd(word* address, word data, byte CMD);
byte EraseEESector(word* address );
byte WriteEEWord(word* address, word data );
byte WriteEEType(byte* address,void* type_to_write, int size_in_bytes );
byte WriteEEFloat(float* address, float data );





