This is a simple program that flashes the LEDs on the
docking board for the Nanocore12 DIP module. 

This module uses a 9s12C32 chip with a Motorola serial monitor.

The NanoCore12 DIP module is available from Technological Arts:
http://www.technologicalarts.com/myfiles/nc12.html