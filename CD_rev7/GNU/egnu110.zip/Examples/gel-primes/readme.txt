This is a demo program by Stephane Carrez.

This must be linked to the GEL library (GNU Embedded Library).
