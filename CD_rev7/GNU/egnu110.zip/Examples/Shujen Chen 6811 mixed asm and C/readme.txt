This example from Shujen Chen is for a FOX11 board.

This has a C language main module that calls an assembler 
routine to update an LCD.

