This program was donated by Steven Lamb. 

This uses some sample serial interrupt code provided by 
Jonathan W. Valvano on his web site:
http://www.ece.utexas.edu/~valvano/

This is an interrupt-driven, SCI I/O pprogram written for the 9S12C32.

This was tested on a NanoCore12 DIP module from Technological Arts:
http://www.technologicalarts.com/myfiles/nc12.html

This uses RTI/OC3 interrupts that occur at different rates.
Each interrupt toggles an LED and sends a char (R for RTI or 3 
for OC3) to the serial port.