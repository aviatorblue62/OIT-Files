package icons;

import com.intellij.openapi.util.IconLoader;

import javax.swing.*;

/**
 * NOTE THIS FILE IS AUTO-GENERATED
 * DO NOT EDIT IT BY HAND, run build/scripts/icons.gant instead
 */
public class PythonPsiApiIcons {
  private static Icon load(String path) {
    return IconLoader.getIcon(path, PythonPsiApiIcons.class);
  }

  public static final Icon PythonFile = load("/icons/com/jetbrains/python/pythonFile.png"); // 16x16
}
